drop extension if exists "pg_net";

create type "public"."payment_status_type" as enum ('pending', 'paid', 'cancelled');

create sequence "public"."failed_jobs_id_seq";

create sequence "public"."jobs_id_seq";

create sequence "public"."migrations_id_seq";

create sequence "public"."users_id_seq";


  create table "public"."cache" (
    "key" character varying(255) not null,
    "value" text not null,
    "expiration" integer not null
      );



  create table "public"."cache_locks" (
    "key" character varying(255) not null,
    "owner" character varying(255) not null,
    "expiration" integer not null
      );



  create table "public"."customer" (
    "customerid" character(6) not null,
    "customername" character varying(100),
    "tel" character varying(10),
    "address" character varying(200),
    "is_company" boolean default false
      );


alter table "public"."customer" enable row level security;


  create table "public"."employee" (
    "employeeid" character(6) not null,
    "empname" character varying(100),
    "position" character varying(80),
    "tel" character varying(10),
    "password" character varying default ''::character varying
      );



  create table "public"."failed_jobs" (
    "id" bigint not null default nextval('public.failed_jobs_id_seq'::regclass),
    "uuid" character varying(255) not null,
    "connection" text not null,
    "queue" text not null,
    "payload" text not null,
    "exception" text not null,
    "failed_at" timestamp(0) without time zone not null default CURRENT_TIMESTAMP
      );



  create table "public"."generates" (
    "receiptid" character(6) not null,
    "orderid" character(6) not null,
    "orderstatus" character varying(50)
      );



  create table "public"."job_batches" (
    "id" character varying(255) not null,
    "name" character varying(255) not null,
    "total_jobs" integer not null,
    "pending_jobs" integer not null,
    "failed_jobs" integer not null,
    "failed_job_ids" text not null,
    "options" text,
    "cancelled_at" integer,
    "created_at" integer not null,
    "finished_at" integer
      );



  create table "public"."jobs" (
    "id" bigint not null default nextval('public.jobs_id_seq'::regclass),
    "queue" character varying(255) not null,
    "payload" text not null,
    "attempts" smallint not null,
    "reserved_at" integer,
    "available_at" integer not null,
    "created_at" integer not null
      );



  create table "public"."migrations" (
    "id" integer not null default nextval('public.migrations_id_seq'::regclass),
    "migration" character varying(255) not null,
    "batch" integer not null
      );



  create table "public"."orders" (
    "orderid" character(6) not null,
    "orderdate" timestamp without time zone,
    "employeeid" character(6),
    "customerid" character(6),
    "totalamount" numeric,
    "discount" numeric default 0,
    "netamount" numeric,
    "payment_status" public.payment_status_type default 'pending'::public.payment_status_type,
    "tax_address_id" character(6)
      );



  create table "public"."product" (
    "productid" character(6) not null,
    "productname" character varying(100),
    "producttype" character varying(100),
    "categories" character varying(80),
    "woodtype" character varying(80),
    "price" numeric(8,2),
    "stock" numeric not null default 0,
    "cost" numeric(10,2) not null default '0'::numeric,
    "supplierid" character varying,
    "received_at" timestamp without time zone default now()
      );



  create table "public"."receipt" (
    "receiptid" character(6) not null,
    "paymentmethod" character varying(100),
    "totalmoneyamount" numeric(10,0),
    "receivedmoneyamount" numeric(10,0),
    "changemoneyamount" numeric(10,0),
    "orderid" character varying(6),
    "receipt_date" timestamp without time zone default now(),
    "created_at" timestamp without time zone default now(),
    "updated_at" timestamp without time zone default now()
      );



  create table "public"."sales_detail" (
    "productid" character(6) not null,
    "orderid" character(6) not null,
    "quantity" numeric(4,0),
    "orderdetailid" character varying(20) not null,
    "price" numeric(10,2) not null,
    "subtotal" numeric(10,2) not null default '0'::numeric
      );



  create table "public"."sessions" (
    "id" character varying(255) not null,
    "user_id" bigint,
    "ip_address" character varying(45),
    "user_agent" text,
    "payload" text not null,
    "last_activity" integer not null
      );



  create table "public"."supplier" (
    "supplierid" character(6) not null,
    "suppliername" character varying(80),
    "address" character varying(200),
    "tel" character varying(10),
    "contactperson" character varying(100)
      );


alter table "public"."supplier" enable row level security;


  create table "public"."tax_address" (
    "taxaddressid" character(6) not null,
    "companyname" character varying(80),
    "taxid" character(13),
    "selleraddress" character varying(200),
    "customerid" character(6),
    "addresstype" character varying(20)
      );


alter table "public"."tax_address" enable row level security;


  create table "public"."users" (
    "id" bigint not null default nextval('public.users_id_seq'::regclass),
    "name" character varying(255) not null,
    "email" character varying(255) not null,
    "email_verified_at" timestamp(0) without time zone,
    "password" character varying(255) not null,
    "remember_token" character varying(100),
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone
      );


alter sequence "public"."failed_jobs_id_seq" owned by "public"."failed_jobs"."id";

alter sequence "public"."jobs_id_seq" owned by "public"."jobs"."id";

alter sequence "public"."migrations_id_seq" owned by "public"."migrations"."id";

alter sequence "public"."users_id_seq" owned by "public"."users"."id";

CREATE UNIQUE INDEX "Order_pkey" ON public.orders USING btree (orderid);

CREATE INDEX cache_expiration_index ON public.cache USING btree (expiration);

CREATE INDEX cache_locks_expiration_index ON public.cache_locks USING btree (expiration);

CREATE UNIQUE INDEX cache_locks_pkey ON public.cache_locks USING btree (key);

CREATE UNIQUE INDEX cache_pkey ON public.cache USING btree (key);

CREATE UNIQUE INDEX customer_pkey ON public.customer USING btree (customerid);

CREATE UNIQUE INDEX employee_pkey ON public.employee USING btree (employeeid);

CREATE UNIQUE INDEX failed_jobs_pkey ON public.failed_jobs USING btree (id);

CREATE UNIQUE INDEX failed_jobs_uuid_unique ON public.failed_jobs USING btree (uuid);

CREATE UNIQUE INDEX generates_pkey ON public.generates USING btree (receiptid, orderid);

CREATE UNIQUE INDEX job_batches_pkey ON public.job_batches USING btree (id);

CREATE UNIQUE INDEX jobs_pkey ON public.jobs USING btree (id);

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);

CREATE UNIQUE INDEX migrations_pkey ON public.migrations USING btree (id);

CREATE UNIQUE INDEX product_pkey ON public.product USING btree (productid);

CREATE UNIQUE INDEX receipt_pkey ON public.receipt USING btree (receiptid);

CREATE UNIQUE INDEX sales_detail_pkey ON public.sales_detail USING btree (productid, orderid, orderdetailid);

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);

CREATE UNIQUE INDEX sessions_pkey ON public.sessions USING btree (id);

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);

CREATE UNIQUE INDEX supplier_pkey ON public.supplier USING btree (supplierid);

CREATE UNIQUE INDEX tax_address_pkey ON public.tax_address USING btree (taxaddressid);

CREATE UNIQUE INDEX users_email_unique ON public.users USING btree (email);

CREATE UNIQUE INDEX users_pkey ON public.users USING btree (id);

alter table "public"."cache" add constraint "cache_pkey" PRIMARY KEY using index "cache_pkey";

alter table "public"."cache_locks" add constraint "cache_locks_pkey" PRIMARY KEY using index "cache_locks_pkey";

alter table "public"."customer" add constraint "customer_pkey" PRIMARY KEY using index "customer_pkey";

alter table "public"."employee" add constraint "employee_pkey" PRIMARY KEY using index "employee_pkey";

alter table "public"."failed_jobs" add constraint "failed_jobs_pkey" PRIMARY KEY using index "failed_jobs_pkey";

alter table "public"."generates" add constraint "generates_pkey" PRIMARY KEY using index "generates_pkey";

alter table "public"."job_batches" add constraint "job_batches_pkey" PRIMARY KEY using index "job_batches_pkey";

alter table "public"."jobs" add constraint "jobs_pkey" PRIMARY KEY using index "jobs_pkey";

alter table "public"."migrations" add constraint "migrations_pkey" PRIMARY KEY using index "migrations_pkey";

alter table "public"."orders" add constraint "Order_pkey" PRIMARY KEY using index "Order_pkey";

alter table "public"."product" add constraint "product_pkey" PRIMARY KEY using index "product_pkey";

alter table "public"."receipt" add constraint "receipt_pkey" PRIMARY KEY using index "receipt_pkey";

alter table "public"."sales_detail" add constraint "sales_detail_pkey" PRIMARY KEY using index "sales_detail_pkey";

alter table "public"."sessions" add constraint "sessions_pkey" PRIMARY KEY using index "sessions_pkey";

alter table "public"."supplier" add constraint "supplier_pkey" PRIMARY KEY using index "supplier_pkey";

alter table "public"."tax_address" add constraint "tax_address_pkey" PRIMARY KEY using index "tax_address_pkey";

alter table "public"."users" add constraint "users_pkey" PRIMARY KEY using index "users_pkey";

alter table "public"."failed_jobs" add constraint "failed_jobs_uuid_unique" UNIQUE using index "failed_jobs_uuid_unique";

alter table "public"."generates" add constraint "generates_orderid_fkey" FOREIGN KEY (orderid) REFERENCES public.orders(orderid) ON UPDATE CASCADE ON DELETE CASCADE not valid;

alter table "public"."generates" validate constraint "generates_orderid_fkey";

alter table "public"."generates" add constraint "generates_receiptid_fkey" FOREIGN KEY (receiptid) REFERENCES public.receipt(receiptid) not valid;

alter table "public"."generates" validate constraint "generates_receiptid_fkey";

alter table "public"."orders" add constraint "Order_customerid_fkey" FOREIGN KEY (customerid) REFERENCES public.customer(customerid) not valid;

alter table "public"."orders" validate constraint "Order_customerid_fkey";

alter table "public"."orders" add constraint "Order_employeeid_fkey" FOREIGN KEY (employeeid) REFERENCES public.employee(employeeid) not valid;

alter table "public"."orders" validate constraint "Order_employeeid_fkey";

alter table "public"."receipt" add constraint "fk_receipt_order" FOREIGN KEY (orderid) REFERENCES public.orders(orderid) ON UPDATE CASCADE ON DELETE CASCADE not valid;

alter table "public"."receipt" validate constraint "fk_receipt_order";

alter table "public"."sales_detail" add constraint "sales_detail_orderid_fkey" FOREIGN KEY (orderid) REFERENCES public.orders(orderid) ON UPDATE CASCADE ON DELETE CASCADE not valid;

alter table "public"."sales_detail" validate constraint "sales_detail_orderid_fkey";

alter table "public"."sales_detail" add constraint "sales_detail_productid_fkey" FOREIGN KEY (productid) REFERENCES public.product(productid) not valid;

alter table "public"."sales_detail" validate constraint "sales_detail_productid_fkey";

alter table "public"."tax_address" add constraint "tax_address_customerid_fkey" FOREIGN KEY (customerid) REFERENCES public.customer(customerid) not valid;

alter table "public"."tax_address" validate constraint "tax_address_customerid_fkey";

alter table "public"."users" add constraint "users_email_unique" UNIQUE using index "users_email_unique";

grant delete on table "public"."cache" to "anon";

grant insert on table "public"."cache" to "anon";

grant references on table "public"."cache" to "anon";

grant select on table "public"."cache" to "anon";

grant trigger on table "public"."cache" to "anon";

grant truncate on table "public"."cache" to "anon";

grant update on table "public"."cache" to "anon";

grant delete on table "public"."cache" to "authenticated";

grant insert on table "public"."cache" to "authenticated";

grant references on table "public"."cache" to "authenticated";

grant select on table "public"."cache" to "authenticated";

grant trigger on table "public"."cache" to "authenticated";

grant truncate on table "public"."cache" to "authenticated";

grant update on table "public"."cache" to "authenticated";

grant delete on table "public"."cache" to "service_role";

grant insert on table "public"."cache" to "service_role";

grant references on table "public"."cache" to "service_role";

grant select on table "public"."cache" to "service_role";

grant trigger on table "public"."cache" to "service_role";

grant truncate on table "public"."cache" to "service_role";

grant update on table "public"."cache" to "service_role";

grant delete on table "public"."cache_locks" to "anon";

grant insert on table "public"."cache_locks" to "anon";

grant references on table "public"."cache_locks" to "anon";

grant select on table "public"."cache_locks" to "anon";

grant trigger on table "public"."cache_locks" to "anon";

grant truncate on table "public"."cache_locks" to "anon";

grant update on table "public"."cache_locks" to "anon";

grant delete on table "public"."cache_locks" to "authenticated";

grant insert on table "public"."cache_locks" to "authenticated";

grant references on table "public"."cache_locks" to "authenticated";

grant select on table "public"."cache_locks" to "authenticated";

grant trigger on table "public"."cache_locks" to "authenticated";

grant truncate on table "public"."cache_locks" to "authenticated";

grant update on table "public"."cache_locks" to "authenticated";

grant delete on table "public"."cache_locks" to "service_role";

grant insert on table "public"."cache_locks" to "service_role";

grant references on table "public"."cache_locks" to "service_role";

grant select on table "public"."cache_locks" to "service_role";

grant trigger on table "public"."cache_locks" to "service_role";

grant truncate on table "public"."cache_locks" to "service_role";

grant update on table "public"."cache_locks" to "service_role";

grant delete on table "public"."customer" to "anon";

grant insert on table "public"."customer" to "anon";

grant references on table "public"."customer" to "anon";

grant select on table "public"."customer" to "anon";

grant trigger on table "public"."customer" to "anon";

grant truncate on table "public"."customer" to "anon";

grant update on table "public"."customer" to "anon";

grant delete on table "public"."customer" to "authenticated";

grant insert on table "public"."customer" to "authenticated";

grant references on table "public"."customer" to "authenticated";

grant select on table "public"."customer" to "authenticated";

grant trigger on table "public"."customer" to "authenticated";

grant truncate on table "public"."customer" to "authenticated";

grant update on table "public"."customer" to "authenticated";

grant delete on table "public"."customer" to "service_role";

grant insert on table "public"."customer" to "service_role";

grant references on table "public"."customer" to "service_role";

grant select on table "public"."customer" to "service_role";

grant trigger on table "public"."customer" to "service_role";

grant truncate on table "public"."customer" to "service_role";

grant update on table "public"."customer" to "service_role";

grant delete on table "public"."employee" to "anon";

grant insert on table "public"."employee" to "anon";

grant references on table "public"."employee" to "anon";

grant select on table "public"."employee" to "anon";

grant trigger on table "public"."employee" to "anon";

grant truncate on table "public"."employee" to "anon";

grant update on table "public"."employee" to "anon";

grant delete on table "public"."employee" to "authenticated";

grant insert on table "public"."employee" to "authenticated";

grant references on table "public"."employee" to "authenticated";

grant select on table "public"."employee" to "authenticated";

grant trigger on table "public"."employee" to "authenticated";

grant truncate on table "public"."employee" to "authenticated";

grant update on table "public"."employee" to "authenticated";

grant delete on table "public"."employee" to "service_role";

grant insert on table "public"."employee" to "service_role";

grant references on table "public"."employee" to "service_role";

grant select on table "public"."employee" to "service_role";

grant trigger on table "public"."employee" to "service_role";

grant truncate on table "public"."employee" to "service_role";

grant update on table "public"."employee" to "service_role";

grant delete on table "public"."failed_jobs" to "anon";

grant insert on table "public"."failed_jobs" to "anon";

grant references on table "public"."failed_jobs" to "anon";

grant select on table "public"."failed_jobs" to "anon";

grant trigger on table "public"."failed_jobs" to "anon";

grant truncate on table "public"."failed_jobs" to "anon";

grant update on table "public"."failed_jobs" to "anon";

grant delete on table "public"."failed_jobs" to "authenticated";

grant insert on table "public"."failed_jobs" to "authenticated";

grant references on table "public"."failed_jobs" to "authenticated";

grant select on table "public"."failed_jobs" to "authenticated";

grant trigger on table "public"."failed_jobs" to "authenticated";

grant truncate on table "public"."failed_jobs" to "authenticated";

grant update on table "public"."failed_jobs" to "authenticated";

grant delete on table "public"."failed_jobs" to "service_role";

grant insert on table "public"."failed_jobs" to "service_role";

grant references on table "public"."failed_jobs" to "service_role";

grant select on table "public"."failed_jobs" to "service_role";

grant trigger on table "public"."failed_jobs" to "service_role";

grant truncate on table "public"."failed_jobs" to "service_role";

grant update on table "public"."failed_jobs" to "service_role";

grant delete on table "public"."generates" to "anon";

grant insert on table "public"."generates" to "anon";

grant references on table "public"."generates" to "anon";

grant select on table "public"."generates" to "anon";

grant trigger on table "public"."generates" to "anon";

grant truncate on table "public"."generates" to "anon";

grant update on table "public"."generates" to "anon";

grant delete on table "public"."generates" to "authenticated";

grant insert on table "public"."generates" to "authenticated";

grant references on table "public"."generates" to "authenticated";

grant select on table "public"."generates" to "authenticated";

grant trigger on table "public"."generates" to "authenticated";

grant truncate on table "public"."generates" to "authenticated";

grant update on table "public"."generates" to "authenticated";

grant delete on table "public"."generates" to "service_role";

grant insert on table "public"."generates" to "service_role";

grant references on table "public"."generates" to "service_role";

grant select on table "public"."generates" to "service_role";

grant trigger on table "public"."generates" to "service_role";

grant truncate on table "public"."generates" to "service_role";

grant update on table "public"."generates" to "service_role";

grant delete on table "public"."job_batches" to "anon";

grant insert on table "public"."job_batches" to "anon";

grant references on table "public"."job_batches" to "anon";

grant select on table "public"."job_batches" to "anon";

grant trigger on table "public"."job_batches" to "anon";

grant truncate on table "public"."job_batches" to "anon";

grant update on table "public"."job_batches" to "anon";

grant delete on table "public"."job_batches" to "authenticated";

grant insert on table "public"."job_batches" to "authenticated";

grant references on table "public"."job_batches" to "authenticated";

grant select on table "public"."job_batches" to "authenticated";

grant trigger on table "public"."job_batches" to "authenticated";

grant truncate on table "public"."job_batches" to "authenticated";

grant update on table "public"."job_batches" to "authenticated";

grant delete on table "public"."job_batches" to "service_role";

grant insert on table "public"."job_batches" to "service_role";

grant references on table "public"."job_batches" to "service_role";

grant select on table "public"."job_batches" to "service_role";

grant trigger on table "public"."job_batches" to "service_role";

grant truncate on table "public"."job_batches" to "service_role";

grant update on table "public"."job_batches" to "service_role";

grant delete on table "public"."jobs" to "anon";

grant insert on table "public"."jobs" to "anon";

grant references on table "public"."jobs" to "anon";

grant select on table "public"."jobs" to "anon";

grant trigger on table "public"."jobs" to "anon";

grant truncate on table "public"."jobs" to "anon";

grant update on table "public"."jobs" to "anon";

grant delete on table "public"."jobs" to "authenticated";

grant insert on table "public"."jobs" to "authenticated";

grant references on table "public"."jobs" to "authenticated";

grant select on table "public"."jobs" to "authenticated";

grant trigger on table "public"."jobs" to "authenticated";

grant truncate on table "public"."jobs" to "authenticated";

grant update on table "public"."jobs" to "authenticated";

grant delete on table "public"."jobs" to "service_role";

grant insert on table "public"."jobs" to "service_role";

grant references on table "public"."jobs" to "service_role";

grant select on table "public"."jobs" to "service_role";

grant trigger on table "public"."jobs" to "service_role";

grant truncate on table "public"."jobs" to "service_role";

grant update on table "public"."jobs" to "service_role";

grant delete on table "public"."migrations" to "anon";

grant insert on table "public"."migrations" to "anon";

grant references on table "public"."migrations" to "anon";

grant select on table "public"."migrations" to "anon";

grant trigger on table "public"."migrations" to "anon";

grant truncate on table "public"."migrations" to "anon";

grant update on table "public"."migrations" to "anon";

grant delete on table "public"."migrations" to "authenticated";

grant insert on table "public"."migrations" to "authenticated";

grant references on table "public"."migrations" to "authenticated";

grant select on table "public"."migrations" to "authenticated";

grant trigger on table "public"."migrations" to "authenticated";

grant truncate on table "public"."migrations" to "authenticated";

grant update on table "public"."migrations" to "authenticated";

grant delete on table "public"."migrations" to "service_role";

grant insert on table "public"."migrations" to "service_role";

grant references on table "public"."migrations" to "service_role";

grant select on table "public"."migrations" to "service_role";

grant trigger on table "public"."migrations" to "service_role";

grant truncate on table "public"."migrations" to "service_role";

grant update on table "public"."migrations" to "service_role";

grant delete on table "public"."orders" to "anon";

grant insert on table "public"."orders" to "anon";

grant references on table "public"."orders" to "anon";

grant select on table "public"."orders" to "anon";

grant trigger on table "public"."orders" to "anon";

grant truncate on table "public"."orders" to "anon";

grant update on table "public"."orders" to "anon";

grant delete on table "public"."orders" to "authenticated";

grant insert on table "public"."orders" to "authenticated";

grant references on table "public"."orders" to "authenticated";

grant select on table "public"."orders" to "authenticated";

grant trigger on table "public"."orders" to "authenticated";

grant truncate on table "public"."orders" to "authenticated";

grant update on table "public"."orders" to "authenticated";

grant delete on table "public"."orders" to "service_role";

grant insert on table "public"."orders" to "service_role";

grant references on table "public"."orders" to "service_role";

grant select on table "public"."orders" to "service_role";

grant trigger on table "public"."orders" to "service_role";

grant truncate on table "public"."orders" to "service_role";

grant update on table "public"."orders" to "service_role";

grant delete on table "public"."product" to "anon";

grant insert on table "public"."product" to "anon";

grant references on table "public"."product" to "anon";

grant select on table "public"."product" to "anon";

grant trigger on table "public"."product" to "anon";

grant truncate on table "public"."product" to "anon";

grant update on table "public"."product" to "anon";

grant delete on table "public"."product" to "authenticated";

grant insert on table "public"."product" to "authenticated";

grant references on table "public"."product" to "authenticated";

grant select on table "public"."product" to "authenticated";

grant trigger on table "public"."product" to "authenticated";

grant truncate on table "public"."product" to "authenticated";

grant update on table "public"."product" to "authenticated";

grant delete on table "public"."product" to "service_role";

grant insert on table "public"."product" to "service_role";

grant references on table "public"."product" to "service_role";

grant select on table "public"."product" to "service_role";

grant trigger on table "public"."product" to "service_role";

grant truncate on table "public"."product" to "service_role";

grant update on table "public"."product" to "service_role";

grant delete on table "public"."receipt" to "anon";

grant insert on table "public"."receipt" to "anon";

grant references on table "public"."receipt" to "anon";

grant select on table "public"."receipt" to "anon";

grant trigger on table "public"."receipt" to "anon";

grant truncate on table "public"."receipt" to "anon";

grant update on table "public"."receipt" to "anon";

grant delete on table "public"."receipt" to "authenticated";

grant insert on table "public"."receipt" to "authenticated";

grant references on table "public"."receipt" to "authenticated";

grant select on table "public"."receipt" to "authenticated";

grant trigger on table "public"."receipt" to "authenticated";

grant truncate on table "public"."receipt" to "authenticated";

grant update on table "public"."receipt" to "authenticated";

grant delete on table "public"."receipt" to "service_role";

grant insert on table "public"."receipt" to "service_role";

grant references on table "public"."receipt" to "service_role";

grant select on table "public"."receipt" to "service_role";

grant trigger on table "public"."receipt" to "service_role";

grant truncate on table "public"."receipt" to "service_role";

grant update on table "public"."receipt" to "service_role";

grant delete on table "public"."sales_detail" to "anon";

grant insert on table "public"."sales_detail" to "anon";

grant references on table "public"."sales_detail" to "anon";

grant select on table "public"."sales_detail" to "anon";

grant trigger on table "public"."sales_detail" to "anon";

grant truncate on table "public"."sales_detail" to "anon";

grant update on table "public"."sales_detail" to "anon";

grant delete on table "public"."sales_detail" to "authenticated";

grant insert on table "public"."sales_detail" to "authenticated";

grant references on table "public"."sales_detail" to "authenticated";

grant select on table "public"."sales_detail" to "authenticated";

grant trigger on table "public"."sales_detail" to "authenticated";

grant truncate on table "public"."sales_detail" to "authenticated";

grant update on table "public"."sales_detail" to "authenticated";

grant delete on table "public"."sales_detail" to "service_role";

grant insert on table "public"."sales_detail" to "service_role";

grant references on table "public"."sales_detail" to "service_role";

grant select on table "public"."sales_detail" to "service_role";

grant trigger on table "public"."sales_detail" to "service_role";

grant truncate on table "public"."sales_detail" to "service_role";

grant update on table "public"."sales_detail" to "service_role";

grant delete on table "public"."sessions" to "anon";

grant insert on table "public"."sessions" to "anon";

grant references on table "public"."sessions" to "anon";

grant select on table "public"."sessions" to "anon";

grant trigger on table "public"."sessions" to "anon";

grant truncate on table "public"."sessions" to "anon";

grant update on table "public"."sessions" to "anon";

grant delete on table "public"."sessions" to "authenticated";

grant insert on table "public"."sessions" to "authenticated";

grant references on table "public"."sessions" to "authenticated";

grant select on table "public"."sessions" to "authenticated";

grant trigger on table "public"."sessions" to "authenticated";

grant truncate on table "public"."sessions" to "authenticated";

grant update on table "public"."sessions" to "authenticated";

grant delete on table "public"."sessions" to "service_role";

grant insert on table "public"."sessions" to "service_role";

grant references on table "public"."sessions" to "service_role";

grant select on table "public"."sessions" to "service_role";

grant trigger on table "public"."sessions" to "service_role";

grant truncate on table "public"."sessions" to "service_role";

grant update on table "public"."sessions" to "service_role";

grant delete on table "public"."supplier" to "anon";

grant insert on table "public"."supplier" to "anon";

grant references on table "public"."supplier" to "anon";

grant select on table "public"."supplier" to "anon";

grant trigger on table "public"."supplier" to "anon";

grant truncate on table "public"."supplier" to "anon";

grant update on table "public"."supplier" to "anon";

grant delete on table "public"."supplier" to "authenticated";

grant insert on table "public"."supplier" to "authenticated";

grant references on table "public"."supplier" to "authenticated";

grant select on table "public"."supplier" to "authenticated";

grant trigger on table "public"."supplier" to "authenticated";

grant truncate on table "public"."supplier" to "authenticated";

grant update on table "public"."supplier" to "authenticated";

grant delete on table "public"."supplier" to "service_role";

grant insert on table "public"."supplier" to "service_role";

grant references on table "public"."supplier" to "service_role";

grant select on table "public"."supplier" to "service_role";

grant trigger on table "public"."supplier" to "service_role";

grant truncate on table "public"."supplier" to "service_role";

grant update on table "public"."supplier" to "service_role";

grant delete on table "public"."tax_address" to "anon";

grant insert on table "public"."tax_address" to "anon";

grant references on table "public"."tax_address" to "anon";

grant select on table "public"."tax_address" to "anon";

grant trigger on table "public"."tax_address" to "anon";

grant truncate on table "public"."tax_address" to "anon";

grant update on table "public"."tax_address" to "anon";

grant delete on table "public"."tax_address" to "authenticated";

grant insert on table "public"."tax_address" to "authenticated";

grant references on table "public"."tax_address" to "authenticated";

grant select on table "public"."tax_address" to "authenticated";

grant trigger on table "public"."tax_address" to "authenticated";

grant truncate on table "public"."tax_address" to "authenticated";

grant update on table "public"."tax_address" to "authenticated";

grant delete on table "public"."tax_address" to "service_role";

grant insert on table "public"."tax_address" to "service_role";

grant references on table "public"."tax_address" to "service_role";

grant select on table "public"."tax_address" to "service_role";

grant trigger on table "public"."tax_address" to "service_role";

grant truncate on table "public"."tax_address" to "service_role";

grant update on table "public"."tax_address" to "service_role";

grant delete on table "public"."users" to "anon";

grant insert on table "public"."users" to "anon";

grant references on table "public"."users" to "anon";

grant select on table "public"."users" to "anon";

grant trigger on table "public"."users" to "anon";

grant truncate on table "public"."users" to "anon";

grant update on table "public"."users" to "anon";

grant delete on table "public"."users" to "authenticated";

grant insert on table "public"."users" to "authenticated";

grant references on table "public"."users" to "authenticated";

grant select on table "public"."users" to "authenticated";

grant trigger on table "public"."users" to "authenticated";

grant truncate on table "public"."users" to "authenticated";

grant update on table "public"."users" to "authenticated";

grant delete on table "public"."users" to "service_role";

grant insert on table "public"."users" to "service_role";

grant references on table "public"."users" to "service_role";

grant select on table "public"."users" to "service_role";

grant trigger on table "public"."users" to "service_role";

grant truncate on table "public"."users" to "service_role";

grant update on table "public"."users" to "service_role";


